#include "Player.h"


Player::Player() {
    for(int i = 0; i < MAX_BULLETS; i++) {
        bullets[i].exists = false;
    }
}

Player::~Player() {
    // free loaded bitmap
    if(image != NULL) {
        SDL_FreeSurface(image->getSurface());
    }
}


void Player::draw(SDL_Surface* screen, int x, int y) {
    image->animate();
    image->draw(screen, x, y);
}
