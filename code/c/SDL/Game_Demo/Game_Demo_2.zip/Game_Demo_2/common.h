#ifndef __COMMON_H__
#define __COMMON_H__

#include <string>
#include <iostream>
#include "math.h"

#include <cstdlib>


#include <SDL/SDL.h>

#include "Sprite.h"


#endif
