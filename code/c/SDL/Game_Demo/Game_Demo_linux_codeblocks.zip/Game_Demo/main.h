#ifndef __MAIN_H__
#define __MAIN_H__

#include "Game.h"

#include "common.h"

#endif
