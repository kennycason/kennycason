#include "Main.h"
/*
    Sprite library for SDL - using bitmaps
    This library was put together by Kenny Cason and is designed to
    be easily implemented into any C++ program using SDL
    Feel free to do what ever you want with it. enjoy!
    Please report any bugs
    kenneth [DOT] cason [AT] gmail [DOT] com
    v1.0
    2009 Sep 20
    www.ken-soft.com
*/


using namespace std;

int main ( int argc, char* argv[] ) {
    bool running = true;
    if ( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
        printf( "Unable to init SDL: %s\n", SDL_GetError());
        running = false;
    }
    // ensure a clean exit
    atexit(SDL_Quit);
    // create a new window
    SDL_Surface* screen = SDL_SetVideoMode(400, 230, 16,
                                           SDL_HWSURFACE|SDL_DOUBLEBUF);
    SDL_WM_SetCaption( "Sprite Example - Samus", "Sprite Example - Samus" );
    if ( !screen ) {
        printf("Unable to set 400x300 video: %s\n", SDL_GetError());
        running = false;
    }
    SDL_Event keyevent;

    Sprite s1 = Sprite("sprites/samus_normal_run.bmp",10,60); // load a BMP that contains 10 frames
                                                // set the animation speed to 60 milliseconds
    s1.setTransparency(255,0,255);      // set RGB(255,0,255) as transparent
                                // NOTE: setTransparency(SDL_Surface->format->colorkey) also works
    Sprite s2 = Sprite(s1.getSurface(),10,60);    // load another copy of the previously loaded BMP
                                            // transparency is also copied over
    s2.flipHorizontal();                    // flip the whole BMP horizontally
    s2.reverseAnimation();      // now reverse the animations, if you don't do this the sprite
                                // will appear to be walking backwards. Observe s6 to see this

    Sprite s3 = Sprite("sprites/samus_normal_run.bmp",10,60); // make another copy
    s3.flipVertical();          // flip it vertically
    s3.setTransparency(255,0,255);

    Sprite s4 = Sprite("sprites/samus_normal_run.bmp",10,20);
    s4.rotate90();
    s4.setTransparency(255,0,255);

    Sprite s5 = Sprite("sprites/samus_normal_run.bmp",10,360);
    s5.rotate180();
    s5.setTransparency(255,0,255);

    Sprite s6 = Sprite("sprites/samus_normal_run.bmp",10,60);
    s6.rotate270();
    s6.setTransparency(255,0,255);

    Sprite s7 = Sprite("sprites/samus_normal_run.bmp",10,60);
    s7.zoom(50);
    s7.setTransparency(255,0,255);


    Sprite s8 = Sprite("sprites/samus_normal_run.bmp",10,300);
    s8.setTransparency(255,0,255);
    s8.zoom(150);


    Sprite s9 = Sprite("sprites/samus_normal_run.bmp",10,68);
    s9.setTransparency(255,0,255);
    s9.stretchX(300);

    Sprite s10 = Sprite("sprites/samus_normal_run.bmp",10,100);
    s10.setTransparency(255,0,255);
    s10.stretchY(200);

    Sprite s11 = Sprite("sprites/samus_normal_run.bmp",10,100);
    s11.setTransparency(255,0,255);
    Sprite s12 = Sprite("sprites/samus_normal_run.bmp",10,100);
    s12.setTransparency(255,0,255);

    Sprite s15 = Sprite("sprites/samus_normal_run.bmp",10,0);
    s15.setTransparency(255,0,255);
    s15.stop();

        for(int y = 0; y < 16; y+=2) {
            for(int x = 0; x < 32; x+=2) {
                for(int i = 0; i < s15.maxFrames; i ++) {
                    s15.setPixel(i*s15.getWidth()+x,y,0xFF0000);
                }
            }
        }
        for(int y = 0; y < 32; y+=2) {
            for(int x = 0; x < 32; x+=2) {
                for(int i = 0; i < s15.maxFrames; i ++) {
                   s15.setTransparentPixel(i*s15.getWidth()+x,y);
                }
            }
        }



    int deg = 0;
    while(running) {
        // clear background to black, RGB(0,0,0)
        SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, 0, 255, 0));

        s1.animate(); // animate the sprite
        s1.draw(screen,0,0);
        s2.animate();
        s2.draw(screen,50,0);

        s3.animate();
        s3.draw(screen,90,0);
        s4.animate();
        s4.draw(screen,140,0);

        s5.animate(); // draw s4 and s5 such that they are overlapping
        s5.draw(screen,185,0);
        s6.animate();
        s6.draw(screen,220,0);


        s7.animate();
        s7.draw(screen,0,70);
        s8.animate();
        s8.draw(screen,30,70);
        s9.animate();
        s9.draw(screen,70,70);
        s10.animate();
        s10.draw(screen,170,70);


        s11.animate();
        s11.draw(screen,210,70);
        s12.animate();
        s12.draw(screen,220,70);


        s15.animate();
        s15.draw(screen,270,0);
        SDL_Flip(screen);
       if(s11.pixelCollide(210,70,s12,220,70)) {
            cout << "s11 and s12 pixel Collision = true!" << endl;
        } else {
            cout << "s11 and s12 pixel Collision = false!" << endl;
        }
        if(s11.rectCollide(210,70,s12,220,70)) {
            cout << "s11 and s12 rectangle Collision = true!" << endl;
        } else {
            cout << "s11 and s12 rectangle Collision = false!" << endl;
        }

     SDL_PollEvent(&keyevent);
        switch(keyevent.type) {
            case SDL_KEYDOWN:
                printf("key down\n");
                switch(keyevent.key.keysym.sym) {
                    case SDLK_ESCAPE:
                        running = false;
                        break;
                    default:
                        break;
                }
                break;
            case SDL_QUIT:
                 running = false;
                 break;
            default:
                break;
        }
    }
    return 0;
}
