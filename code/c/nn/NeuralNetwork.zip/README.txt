ABOUT: Train a back error propagation neural network to be able to perform Logical AND three inputs
AUTHOR: Kenny Cason
WEBSITE: Ken-Soft.com
EMAIL: kenneth.cason@gmail.com
DATE: 10-1-2010
Feel free to do whatever you want with the source code. Just please give credit! :)

1. Compile:
g++ *.cpp -o NeuralNetwork
2. Run:
./NeuralNetwork
3. Output:
Neural Network Connections Inited
 Trained in 10000 trails within an error of 1.03127e-05
0 & 0 = 4.63117e-05
0 & 1 = 0.00349833
1 & 0 = 0.00290835
1 & 1 = 0.995469
Train Logical AND 2 Inputs Demo End
Neural Network Connections Inited
Training...
 Trained in 5584 trails within an error of 9.99977e-06
0 & 0 & 0 = 3.62242e-05
0 & 0 & 1 = 0.00194301
0 & 1 & 0 = 0.000102096
0 & 1 & 1 = 0.00344352
1 & 0 & 0 = 0.000142368
1 & 0 & 1 = 0.00333881
1 & 1 & 0 = 0.0035418
1 & 1 & 1 = 0.993633
Logical AND 3 Inputs Demo End

