#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "stack.h"

#define DEFAULT_IN_FILE "in.k2"
#define DEFAULT_STACK_SIZE 64

char inFile[256] = DEFAULT_IN_FILE;

/* function definitions */
void runInstructions();
int loadFile(char inFile[256]);
void printInstructions();


Stack stack;
int stackSize = DEFAULT_STACK_SIZE;

unsigned char* instructions; /* the Instructions loaded from input file */
int instructionsSize = 0;


/*
 *
 */
int main(int argc, char *argv[]) {
    int i;
    for(i = 1; i < argc; i++) { /* handle parameters */
        if(strcmp(argv[i], "-i") == 0) { /* input file */
            if( i + 1 < argc) {
                sprintf(inFile, "%s", argv[i + 1]);
            } else {  /* improper format */
                return -1;
            }
        } else if(strcmp(argv[i], "-size") == 0) { /* size of stack */
            if( i + 1 < argc) {
                stackSize = atoi(argv[i + 1]);
            } else {  /* improper format */
                return -1;
            }
        }
    }

    init(&stack, stackSize);

    loadFile(inFile);

    runInstructions();
    return 0;
}


void runInstructions() {
    int IP; // instruction
    unsigned int i; char c; // used to store user input
    unsigned int op1, op2;
    StackContent content;
    for(IP = 0; IP < instructionsSize; IP++) {
        switch(instructions[IP]) {
            case '>': /* INC/DEC */


                break;
            case '<':

                break;
            case '+': /* ADD top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = op2 + op1;
                push(&stack, content);
                break;
            case '-': /* SUB top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = op2 - op1;
                push(&stack, content);
                break;
            case '*': /* MUL top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = op2 * op1;
                push(&stack, content);
                break;
            case '^': /* POW top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = pow (op2, op1);
                push(&stack, content);
                break;
            case '/': /* DIV top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = op2 / op1;
                push(&stack, content);
                break;
            case '%': /* MOD top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = op2 % op1;
                push(&stack, content);
                break;
            case '|': /* OR top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = op2 | op1;
                push(&stack, content);
                break;
            case '&': /* AND top two operators  */
                content = pop(&stack);
                op1 = content.data;
                content = pop(&stack);
                op2 = content.data;
                content.data = op2 & op1;
                push(&stack, content);
                break;
            case '!': /* NOT top operator  */
                content = pop(&stack);
                op1 = content.data;
                content.data = !op1;
                push(&stack, content);
                break;
            case '?': /* IF top operator > 0, push it back, else pop */
                content = pop(&stack);
                op1 = content.data;
                if(op1 > 0) {
                    content.data = op1;
                    push(&stack, content);
                }
                break;
            case '@': /* push the address of the item on the top of the stack */
                content = pop(&stack);
                push(&stack, content);
                content.data = &content.data;
                push(&stack, content);
                break;
            case '$': /* pop the value of the item being referenced to by the top item in the stack, then push back the reference, and then the value*/
                content = pop(&stack);
                push(&stack, content);
                printf("content.data = %d, *P = %d\n", content.data, * (unsigned int*)content.data);
                push(&stack, content);
                break;
            case 'c':  /* OUTPUT */
                content = pop(&stack);
                printf("%c",content.data);
                break;
            case 'd':
                content = pop(&stack);
                printf("%u",content.data);
                break;
            case 'C': /* INPUT */
                while (scanf("%c", &c) != 1);
                content.data = (unsigned int)c;
                push(&stack, content);
                break;
            case 'D':
                while (scanf("%u", &i) != 1);
                content.data = i;
                push(&stack, content);
                break;
            case 'X': /* empty stack */
                while (!isEmpty(&stack)) {
                    pop(&stack);
                }
                break;
            case 'S': /* print Stack */
                print(&stack);
                break;
            case 'I': /* print Instructions */
                printInstructions();
                break;
            default:
                /* is it a number ? */
                if(instructions[IP] >= 48 && instructions[IP] <= 57) {
                    content.data = atoi(&instructions[IP]); /* this will actually read until the first space */
                    push(&stack, content);
                    while(instructions[IP] >= 48 && instructions[IP] <= 57) {
                        IP++; /* skip past the numeric ascii values that were just converted using atoi() */
                    }
                }
                /* it is some other char, push it if not ")" or "(" */
                if(instructions[IP] != '(' && instructions[IP] != ')'
                   && instructions[IP] != ' ' && instructions[IP] != '\n') {
                    content.data = instructions[IP];
                    push(&stack, content);
                  //  printf("push %c", content.data);
                }
                /* unknown command, ignore it */
                break;
        }
    }
}


/*
 *
 */
int loadFile(char inFile[256]) {
    FILE *fp;
    fp=fopen(inFile, "r");
    if(fp == NULL) {
        return -1;
    }
    fseek(fp, 0, SEEK_END); // seek to end of file
    instructionsSize = ftell(fp); // get current file pointer
    rewind (fp);
    instructions = (char*) malloc( instructionsSize );
    int i;
    for(i = 0; i < instructionsSize; i++) {
        instructions[i] = ' ';
    }
    if(instructions == NULL) {
        return -1;
    }
    fread (instructions,1,instructionsSize,fp);
    fclose(fp);
    return 0;
}

/*
 *
 */
void printInstructions() {
    int i;
    for(i = 0; i < instructionsSize; i++) {
        printf("%c", instructions[i]);
    }
    printf("\n");
}
