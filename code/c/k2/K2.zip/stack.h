#ifndef __C__STACK__H__
#define __C__STACK__H__
typedef struct {
    unsigned int data;  // the value being stored on the stack
} StackContent;

typedef struct {
  StackContent *contents;
  int top;
  int maxSize;
} Stack;

void init(Stack *stackP, int maxSize);
void destroy(Stack *stackP);
void push(Stack *stackP, StackContent element);
StackContent pop(Stack *stackP);
int isEmpty(Stack *stackP);
int isFull(Stack *stackP);


void init(Stack *stackP, int maxSize) {
    StackContent *newContents;
    /* Allocate a new array to hold the contents. */
    newContents = (StackContent *)malloc(sizeof(StackContent) * maxSize);
    if (newContents == NULL) {
        fprintf(stderr, "Insufficient memory to initialize stack.\n");
        exit(1);  /* Exit, returning error code. */
    }
    stackP->contents = newContents;
    stackP->maxSize = maxSize;
    stackP->top = -1;  /* I.e., empty */
}

void destroy(Stack *stackP) {
    /* Get rid of array. */
    free(stackP->contents);
    stackP->contents = NULL;
    stackP->maxSize = 0;
    stackP->top = -1;  /* I.e., empty */
}

int isEmpty(Stack *stackP) {
    return stackP->top < 0;
}

int isFull(Stack *stackP) {
    return stackP->top >= stackP->maxSize - 1;
}

void push(Stack *stackP, StackContent element) {
    if (isFull(stackP)) {
        fprintf(stderr, "Can't push element on stack: stack is full.\n");
        exit(1);  /* Exit, returning error code. */
    }
    /* Put information in array; update top. */
    stackP->contents[++stackP->top] = element;
}

StackContent pop(Stack *stackP) {
    if (isEmpty(stackP)) {
        fprintf(stderr, "Can't pop element from stack: stack is empty.\n");
        exit(1);  /* Exit, returning error code. */
    }
    return stackP->contents[stackP->top--];
}

void print(Stack *stackP) {
    int i = 0;
    printf("stack:\n");
    for(i = stackP->top; i >= 0; i--) {
        printf("[%d]\n",stackP->contents[i].data);
    }
}

#endif
