
#include <iostream>
#include <cstdlib>
#include <SDL/SDL.h>

#include "Vector4D.h"
using namespace std;

/*
AUTHOR: Kenny Cason
WEBSITE: Ken-Soft.com
EMAIL: kenneth.cason@gmail.com
DATE: 11-19-2009
*/

void setPixel(SDL_Surface* surface, int x, int y, Uint32 pixel);

int main ( int argc, char** argv ) {
    // initialize SDL video
    if ( SDL_Init( SDL_INIT_VIDEO ) < 0 ) {
        cout <<  "Unable to init SDL: %s\n" << SDL_GetError() << endl;
        return 1;
    }

    // make sure SDL cleans up before exit
    atexit(SDL_Quit);

    // create a new window
    SDL_Surface* screen = SDL_SetVideoMode(640, 480, 16,
                                           SDL_HWSURFACE|SDL_DOUBLEBUF);
    if (!screen) {
        cout << "Unable to set 640x480 video: %s\n" << SDL_GetError() << endl;
        return 1;
    }
    int NUM_POINTS = 1000;
    Vector4D vs[NUM_POINTS];
    for(int i = 0; i < NUM_POINTS; i++) {
        vs[i].x = rand()%300 - 150;
        vs[i].y = rand()%300 - 150;
        vs[i].z = rand()%300 - 150;
        vs[i].u = rand()%300 - 150;
       // cout << "X = " << vs[i].x << " Y = " << vs[i].y << " Z = " << vs[i].z << " U = " << vs[i].u << endl;
    }

    double theta = 0;
    double xaxis = 320;
    double yaxis = 240;

    bool done = false;
    while (!done) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {

            switch (event.type) {
                case SDL_QUIT:
                    done = true;
                    break;
                case SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_ESCAPE)
                        done = true;
                    break;
            }
        }

        SDL_FillRect(screen, 0, SDL_MapRGB(screen->format, 0, 0, 0));

        theta += 2.0;
        if(theta >= 360) {
                theta = 0;
        }
        double rad = degToRad(theta);
    //    cout << "THETA :" << theta << endl;

        for(int i = 0; i < NUM_POINTS; i++) {
            Vector4D newv;
            newv = rotateXY(vs[i], rad);
            newv = rotateYZ(newv, rad);
            newv = rotateXZ(newv, rad);
            newv = rotateXU(newv, -rad);
            newv = rotateYU(newv, -rad);
            newv = rotateZU(newv, rad);

            setPixel(screen, newv.x + xaxis, newv.y + yaxis,  SDL_MapRGB(screen->format, 255, 255, 255));
        }


        SDL_Flip(screen);
    }

    printf("Exited cleanly\n");
    return 0;
}



void setPixel(SDL_Surface* surface, int x, int y, Uint32 pixel) {
    if(surface == NULL) {
         cout << "Failed to set pixel, surface not initialized!"<< endl;
         return;
     }
    if(x < 0 || x > surface->w || y < 0 || y > surface->h) {
       //  cout << "Pixel not within surface's dimensions"<< endl;
         return;
     }
    int bpp = surface->format->BytesPerPixel;
    /* p is the address to the pixel we want to set */
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;
    switch(bpp) {
        case 1:
            *p = pixel;
            break;
        case 2:
            *(Uint16 *)p = pixel;
            break;
        case 3:
            if(SDL_BYTEORDER == SDL_BIG_ENDIAN) {
                p[0] = (pixel >> 16) & 0xff;
                p[1] = (pixel >> 8) & 0xff;
                p[2] = pixel & 0xff;
            } else {
                p[0] = pixel & 0xff;
                p[1] = (pixel >> 8) & 0xff;
                p[2] = (pixel >> 16) & 0xff;
            }
            break;
        case 4:
            *(Uint32 *)p = pixel;
            break;
    }
}
