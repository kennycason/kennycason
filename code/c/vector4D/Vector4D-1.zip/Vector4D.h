#ifndef __VECTOR_4D_H__
#define __VECTOR_4D_H__

#include "math.h"

/*
ABOUT: 4D Vector and rotation functions. Rotations about XY, YZ, XZ, XU, YU, and ZU
AUTHOR: Kenny Cason
WEBSITE: Ken-Soft.com
EMAIL: kenneth.cason@gmail.com
DATE: 11-19-2009
*/


#define PI 3.14159265358979323846264338327950288

struct Vector4D {
    double x;
    double y;
    double z;
    double u;
};

static Vector4D& rotateXY(struct Vector4D &Vector, double theta);
static Vector4D& rotateYZ(struct Vector4D &vector, double theta);
static Vector4D& rotateXZ(struct Vector4D &vector, double theta);
static Vector4D& rotateXU(struct Vector4D &Vector, double theta);
static Vector4D& rotateYU(struct Vector4D &Vector, double theta);
static Vector4D& rotateZU(struct Vector4D &Vector, double theta);
static Vector4D& getUnitVector4D(struct Vector4D &vector);;
static Vector4D& rotateAroundVector4D(struct Vector4D &vect1, struct Vector4D &vect2, double theta);
static double degToRad(double deg);

	/**
	 * [(cos(a), -sin(a), 0, 0),
	 *  (sin(a), cos(a) , 0, 0),
	 *  (0     , 0      , 1, 0),
	 *  (0	   , 0		, 0, 1)]
	 * @param point
	 * @param theta
	 * @return
	 */
Vector4D& rotateXY(struct Vector4D &vector, double theta) {
    Vector4D newv;
    newv.x = vector.x * cos(theta) + vector.y * -sin(theta);
    newv.y = vector.x * sin(theta) + vector.y * cos(theta);
    newv.z = vector.z;
    newv.u = vector.u;
    return newv;
}

/**
	 * [(1, 0      , 0     , 0),
	 *  (0, cos(a) , sin(a), 0),
	 *  (0, -sin(a), cos(a), 0),
	 *  (0,        , 0     , 1)]
	 * @param Vector4D
	 * @param theta
	 * @return
	 */
Vector4D& rotateYZ(struct Vector4D &vector, double theta) {
    Vector4D newv;
    newv.x = vector.x;
    newv.y = vector.y * cos(theta) + vector.z * sin(theta);
    newv.z = vector.y * -sin(theta) + vector.z * cos(theta);
    newv.u = vector.u;
    return newv;
}

/**
	 * [(cos(a), 0, -sin(a), 0),
	 *  (0     , 1, 0      , 0),
	 *  (sin(a), 0, cos(a) , 0),
	 *  (0     , 0, 0      , 1)]
	 * @param Vector4D
	 * @param theta
	 * @return
	 */
Vector4D& rotateXZ(struct Vector4D &vector, double theta) {
    Vector4D newv;
    newv.x = vector.x * cos(theta) + vector.z * -sin(theta);
    newv.y = vector.y;
    newv.z = vector.x * sin(theta) + vector.y * cos(theta);
    newv.u = vector.u;
    return newv;
}

/**
	 * [(cos(a) , 0, 0, sin(a)),
	 *  (0      , 1, 0, 0),
	 *  (0      , 0, 1, 0),
	 *  (-sin(a), 0, 0, cos(a))]
	 * @param Vector4D
	 * @param theta
	 * @return
	 */
Vector4D& rotateXU(struct Vector4D &vector, double theta) {
    Vector4D newv;
    newv.x = vector.x * cos(theta) + vector.u * sin(theta);
    newv.y = vector.y;
    newv.z = vector.z;
    newv.u = vector.x * -sin(theta) + vector.y * cos(theta);
    return newv;
}


/**
	 * [(1, 0     , 0, 0),
	 *  (0, cos(a), 0, -sin(a)),
	 *  (0, 0     , 1, 0),
	 *  (0, sin(a),	0, cos(a))]
	 * @param Vector4D
	 * @param theta
	 * @return
	 */
Vector4D& rotateYU(struct Vector4D &vector, double theta) {
    Vector4D newv;
    newv.x = vector.x;
    newv.y = vector.y * cos(theta) + vector.u * -sin(theta);
    newv.z = vector.z;
    newv.u = vector.y * -sin(theta) + vector.u * cos(theta);
    return newv;
}

/**
	 * [(1, 0, 0     , 0),
	 *  (0, 1, 0     , 0),
	 *  (0, 0, cos(a), -sin(a)),
	 *  (0, 0, sin(a), cos(a))]
	 * @param Vector4D
	 * @param theta
	 * @return
	 */
Vector4D& rotateZU(struct Vector4D &vector, double theta) {
    Vector4D newv;
    newv.x = vector.x;
    newv.y = vector.y;
    newv.z = vector.z * cos(theta) + vector.u * -sin(theta);
    newv.u = vector.z * sin(theta) + vector.u * cos(theta);
    return newv;
}

/**
  * returns a unit vector
  */
Vector4D& getUnitVector(struct Vector4D &vector) {
    Vector4D newv;
    double d = sqrt(vector.x * vector.x + vector.y * vector.y +  vector.z * vector.z + vector.u * vector.u);
    newv.x = vector.x / d;
    newv.y = vector.y / d;
    newv.z = vector.z / d;
    newv.u = vector.u / d;
    return newv;
}


/**
  * using quaternions to rotate around an arbirtuary axis
  * Given angle theta in radians and unit vector u = ai + bj + ck or (a,b,c)
  *
  *
  * @param Vector4D 1
  * @param Vector4D 2
  * @param theta
  * @return Vector
  */
Vector4D& rotateAroundVector(Vector4D &vect1, Vector4D &vect2, double theta) {

    Vector4D newv;
    Vector4D unit = getUnitVector(vect2);

    return newv;
}

/**

  */
double degToRad(double deg) {
    return deg * PI / 180;
}

#endif
