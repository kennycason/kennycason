#include <stdio.h>
#include <stdlib.h>

#define DEFAULT_IN_FILE "in.k"
#define DEFAULT_MEMORY_SIZE 10

char inFile[256] = DEFAULT_IN_FILE;

/* function definitions */
int runInstructions();
int loadFile(char inFile[256]);
void printInstructions();
void clearDataBuffer();
void printDataBuffer();


unsigned int* data; /* data buffer, all program data is stored in here */
unsigned int dataSize = 0;

unsigned int IP; // instruction pointer

unsigned char* instructions; /* the Instructions loaded from input file */
unsigned int instructionsSize = 0;

unsigned int* DP = NULL; /* data Pointer */

/*
 *
 */
int main(int argc, char *argv[]) {
    int i;
    for(i = 1; i < argc; i++) { /* handle parameters */
        if(strcmp(argv[i], "-i") == 0) { /* input file */
            if( i + 1 < argc) {
                sprintf(inFile, "%s", argv[i + 1]);
            } else {  /* improper format */
                return -1;
            }
        } else if(strcmp(argv[i], "-size") == 0) { /* size of data buffer */
            if( i + 1 < argc) {
                data = (unsigned int*) malloc( atoi(argv[i + 1]) * sizeof(unsigned int) );
                dataSize = atoi(argv[i + 1]);
            } else {  /* improper format */
                return -1;
            }
        }
    }
    if(dataSize == 0) {
        data = (unsigned int*) malloc( DEFAULT_MEMORY_SIZE * sizeof(unsigned int) );
        dataSize = DEFAULT_MEMORY_SIZE;
    }
    DP = data;

    loadFile(inFile);
    clearDataBuffer();

    return runInstructions();
}


int runInstructions() {
    int i; // used in for loops
    int numCloseBrackets = 0;
    int numOpenBrackets = 0;

    for(IP = 0; IP < instructionsSize; IP++) {
        switch(instructions[IP]) {
            case '>': /* INC/DEC */
                ++DP;

                break;
            case '<':
                --DP;
                break;
            case '+': /* INC/DEC POINTER */
                ++(*DP);
                break;
            case '-':
                --(*DP);
                break;
            case '@': /* STORE IP TO DATA POINTER i.e. Store a Label to IP and INC DATA POINTER */
                *DP = IP;
                break;
            case '?': /* IF DATA POINTER != 0 JUMP to STORED IP */
                if(*DP != 0) { /* now read the next integer as the DP offset to jump to */
                    for(i = IP + 1; i < instructionsSize; i++) {
                        if(instructions[i] >= 48 && instructions[i] <= 57) { /* is the next argument a number? */
                           unsigned int offset = atoi(&instructions[i]); /* this will actually read until the first space */
                           IP = (data[offset]);
                           DP = &data[offset];
                           break;
                        }
                    }
                }
                break;
            case '#': /* End point, return value of *DP */
                return *DP;
                break;
            case 'c':  /* OUTPUT */
                printf("%c",(char)*DP);
                break;
            case 'd':
                printf("%u",*DP);
                break;
            case 'C': /* INPUT */
                while (scanf("%c", DP) != 1);
                break;
            case 'D':
                while (scanf("%u", DP) != 1);
                break;

            case 'M': /* print Data Buffer */
                printDataBuffer();
                break;
            case 'I': /* print Instructions as is*/
                printInstructions();
                break;

            default:
                /* unknown command, ignore it */
                break;
        }
    }
}


/*
 *
 */
int loadFile(char inFile[256]) {
    FILE *fp;
    fp=fopen(inFile, "r");
    if(fp == NULL) {
        return -1;
    }
    fseek(fp, 0, SEEK_END); // seek to end of file
    instructionsSize = ftell(fp); // get current file pointer
    rewind (fp);
    instructions = (char*) malloc( instructionsSize );
    int i;
    for(i = 0; i < instructionsSize; i++) {
        instructions[i] = ' ';
    }
    if(instructions == NULL) {
        return -1;
    }
    fread (instructions,1,instructionsSize,fp);
    fclose(fp);
    return 0;
}

/*
 *
 */
void printInstructions() {
    int i;
    for(i = 0; i < instructionsSize; i++) {
        printf("%c", instructions[i]);
    }
    printf("\n");
}

/*
 *
 */
void clearDataBuffer() {
    int i;
    for(i = 0; i < dataSize; i++) {
        data[i] = 0;
    }
}

/*
 *
 */
void printDataBuffer() {
    int i;
    printf("\n");
    for(i = 0; i < dataSize; i++) {
        printf("[%d]=%d", i, data[i]);
        if(DP == &data[i]) {
            printf(" <-- (DP)");
        }
        printf("\n");
    }
    printf("IP = %d\n", IP);
}
