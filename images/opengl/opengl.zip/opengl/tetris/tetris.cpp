/*
 * FreeGLUT Shapes Demo
 *
 * Written by Nigel Stewart November 2003
 *
 * This program is test harness for the sphere, cone 
 * and torus shapes in FreeGLUT.
 *
 * Spinning wireframe and smooth shaded shapes are
 * displayed until the ESC or q key is pressed.  The
 * number of geometry stacks and slices can be adjusted
 * using the + and - keys.
 */

#include <GL/glut.h>

#include <stdlib.h>

static int slices = 16;
static int stacks = 16;

struct {
  struct {
    float pos[3];
    float col[3];
  } ver[8];

  struct {
    unsigned int ver[4];
  } quad[6];
} cube;

/* GLUT callback Handlers */

static void resize(int width, int height)
{
    const float ar = (float) width / (float) height;
    
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-ar, ar, -1.0, 1.0, 2.0, 100.0);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity() ;
}

static void initCube(void) {
  //defines the position of each vertex
  float  vertexPosDat[8][3]= {
    {-1, 1, 1},  //left,top,front
    {1, 1, 1},   //right,top,front
    {1, 1,-1},   //right,top,back
    {-1, 1,-1},  //left, top,back
    {-1,-1, 1},  //left,bottom,front
    {1, -1, 1},  //right,bottom,front
    {1, -1,-1},  //right,bottom,back
    {-1,-1,-1}   //left,bottom,back
  };
  
   //defines the colour of each vertex
  float   vertexColDat[8][3] = {
    {0.5, 0 ,0},   //dark red
    {1, 1, 0.3},   //yellow
    {0.9, 0.5, 0}, //orange
    {0.5, 1, 0.2}, //dull yellow??
    {1, 1, 0},     //yellow
    {0.9, 0.5, 0}, //orange
    {1, 0.9, 0.1}, //yellow
    {1, 0, 0},     //red
  };
  
  //defines the vertexes of each quad in anti-clockwise order
  unsigned int quadVerDat[6][4] = {
    {0,1,2,3},  //top
    {0,3,7,4},  //left
    {3,2,6,7},  //back
    {2,1,5,6},  //right
    {0,4,5,1},  //front
    {4,7,6,5},  //bottom
  };
  
  int a,b;

  //put the vertex data into the cube.ver[] struct
  for (a=0;a<8;++a) {
    for (b=0;b<3;++b) {
      cube.ver[a].pos[b]=vertexPosDat[a][b];
      cube.ver[a].col[b]=vertexColDat[a][b];
    }
  }

  //put the quad data into the cube.quad[] struct
  for (a=0;a<6;++a) {
    for (b=0;b<4;++b) {
      cube.quad[a].ver[b]=quadVerDat[a][b];
    }
  }
} //end of cubeInit()

static void drawCube(int posX, int posY, int posZ, int rotX, int rotY, int rotZ, int size) {
      unsigned int currentVer;
      glPushMatrix();
      glTranslatef(posX, posY, posZ);
      glRotated(110,1,0,0);
      glColor3d(1,0,1);
      
      glRotated(rotX,1,0,0);
      glRotated(rotY,0,1,0);
      glRotated(rotZ,0,0,1);
      
      glScaled(size, size, size);
      
      glBegin(GL_QUADS); 
          for (int q = 0; q < 6; ++q) {                        //quads loop
              for (int v = 0; v < 4; ++v) {                         //points loop
                  currentVer = cube.quad[q].ver[v];            //sets the current vertex to this point's vertex
                  glColor3fv(cube.ver[ currentVer ].col);    //changes the colour to the current vertex's colour
                  glVertex3fv(cube.ver[ currentVer ].pos);   //draws a vertex at the current vertex's position
              }
          }
      glEnd();
    glPopMatrix();
}

static void display() {
    const double t = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
    
    const double rotX = 10;
    const double rotY = 0;
    const double rotZ = t*90.0;

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glColor3d(1,1,0);


    drawCube(0,0,-50, rotX, rotY, rotZ, 2);
    drawCube(5,0,-50, rotX, rotY, rotZ, 2);
    drawCube(-5,0,-50, rotX, rotY, rotZ, 2);
   
    drawCube(0,5,-50, rotX, rotY, rotZ, 2);
    
    glutSwapBuffers();
}


static void key(unsigned char key, int x, int y) {
    switch (key) 
    {
        case 27 : 
        case 'q':
            exit(0);
            break;

        case '+':
            slices++;
            stacks++;
            break;

        case '-':
            if (slices>3 && stacks>3)
            {
                slices--;
                stacks--;
            }
            break;
    }

    glutPostRedisplay();
}

static void 
idle(void)
{
    glutPostRedisplay();
}

const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

/* Program entry point */

int 
main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitWindowSize(600,800);
    glutInitWindowPosition(10,10);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("FreeGLUT Shapes");

    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutKeyboardFunc(key);
    glutIdleFunc(idle);

    glClearColor(1,1,1,1);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);
//    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

    initCube();
    glutMainLoop();
    

    return EXIT_SUCCESS;
}

